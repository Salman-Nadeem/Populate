import React from 'react'

import './Style.css';
import { BrowserRouter,Routes,Route } from 'react-router-dom';

import Navbar from './Component/Navbar'


import AddmissionForm from './Pages/AddmissionForm';



const App = () => {
  return (
    <BrowserRouter>

    <Navbar/>

    <Routes>
      <Route path="/" element={<AddmissionForm/>}/>
    </Routes>
    </BrowserRouter>
  )
}

export default App