import React, { useEffect, useState } from 'react';
import axios from 'axios'; // Make sure axios is installed: npm install axios

const ProductForm = () => {

  // States for form fields
  const [P_Name, setP_Name] = useState('');
  const [P_Price, setP_Price] = useState('');
  const [P_Category, setP_Category] = useState('');
  const [categoryList, setCategoryList] = useState([]);  
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Function to fetch categories
  const getData = async () => {
    try {
      const response = await axios.get('http://localhost:5000/cat/');
      console.log('API Response:', response.data);
  
      // Check if it's an array
      if (Array.isArray(response.data)) {

        setCategoryList(response.data); // Store the categories in state
      } else {
        setError('Invalid data format for categories');
      }
    } catch (error) {
      console.error('Error:', error);
      setError('Failed to fetch categories');
    }
  };

  // UseEffect to fetch data when the component mounts
  useEffect(() => {
    getData(); // This will run when the component mounts
  }, []);

  // Handle form submit
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!P_Name || !P_Price || !P_Category) {
      setError('All fields are required');
      return;
    }

    const productData = { P_Name, P_Price, P_Category };

    try {
      // Make the POST request with axios
      const response = await axios.post('http://localhost:5000/', productData);

      // Assuming the response is successful
      setSuccess('Product added successfully');
      setError('');
      console.log(response.data);  // Logs the response from the server
    } catch (err) {
      // Log the error message
      console.error("Error:", err.response ? err.response.data : err.message);
      setError(err.response ? err.response.data.message : 'Error adding product');
      setSuccess('');
    }
};


  return (
    <div className="container mt-5">
      <h1 className="text-center mt-5">Add Product</h1>
      
      {error && <div className="alert alert-danger">{error}</div>} {/* Display error */}
      {success && <div className="alert alert-success">{success}</div>} {/* Display success */}

      <form className="mt-4" onSubmit={handleSubmit} method='post'>
        <div className="mb-3">
          <label htmlFor="P_Name" className="form-label">Product Name</label>
          <input
            type="text"
            className="form-control"
            id="P_Name"
            value={P_Name}
            onChange={(e) => setP_Name(e.target.value)} // Bind the state with the input field
          />
        </div>

        <div className="mb-3">
          <label htmlFor="P_Price" className="form-label">Price</label>
          <input
            type="number"
            className="form-control"
            id="P_Price"
            value={P_Price}
            onChange={(e) => setP_Price(e.target.value)} // Bind the price state with the input field
          />
        </div>

        <div className="mb-3">
          <label htmlFor="P_Category" className="form-label">Category</label>
        <select
  id="P_Category"
  className="form-control"
  value={P_Category}
  onChange={(e) => setP_Category(e.target.value)} // Bind the category state with the select field
>
  <option value="">Select a category</option>
  {categoryList.length > 0 ? (
    categoryList.map((category) => (
      <option key={category._id} value={category.P_Cat}>
        {category.P_Cat}
      </option>
    ))
  ) : (
    <option value="" disabled>No categories available</option>
  )}
</select>
        </div>

        <button type="submit" className="btn btn-dark">Submit</button>
      </form>
    </div>
  );
};

export default ProductForm;
