const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define Product Schema
const productSchema = new Schema({
  P_Name: { type: String, required: true },
  P_Price: { type: Number, required: true },
  P_Category: { type: mongoose.Schema.Types.ObjectId, ref: 'P_Category', required: true }  // Ensure this is 'P_Category'
});

// Create the model
const Product = mongoose.model('Product', productSchema);
module.exports = Product;
