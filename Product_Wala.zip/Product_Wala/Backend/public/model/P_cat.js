const mongoose = require('mongoose');


const P_CategorySchema = new mongoose.Schema({
    P_Cat: {
        type: String,
        required: true,
    },
    P_Status: {
        type: String,  
        required: true,
    },
});


const P_Category = mongoose.model('P_Category', P_CategorySchema);

module.exports = P_Category;
